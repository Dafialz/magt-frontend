var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// functions/refmap.js
var refmap_exports = {};
__export(refmap_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(refmap_exports);
async function handler(event) {
  const { UPSTASH_URL, UPSTASH_TOKEN } = process.env;
  if (!UPSTASH_URL || !UPSTASH_TOKEN)
    return { statusCode: 501, body: JSON.stringify({ error: "KV not configured" }) };
  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${UPSTASH_TOKEN}`
  };
  if (event.httpMethod === "GET") {
    const owner = (event.queryStringParameters?.owner || "").trim();
    if (!owner) return { statusCode: 400, body: JSON.stringify({ error: "owner required" }) };
    const key = `magt:ref:${owner}`;
    const res = await fetch(`${UPSTASH_URL}/get/${encodeURIComponent(key)}`);
    if (!res.ok) return { statusCode: 500, body: JSON.stringify({ error: "kv get failed" }) };
    const json = await res.json().catch(() => ({}));
    const ref = json?.result || null;
    return { statusCode: 200, body: JSON.stringify({ ref }) };
  }
  if (event.httpMethod === "POST") {
    let body = {};
    try {
      body = JSON.parse(event.body || "{}");
    } catch {
    }
    const owner = (body.owner || "").trim();
    const ref = (body.ref || "").trim();
    if (!owner || !ref) return { statusCode: 400, body: JSON.stringify({ error: "owner/ref required" }) };
    const key = `magt:ref:${owner}`;
    const chk = await fetch(`${UPSTASH_URL}/get/${encodeURIComponent(key)}`);
    const ex = chk.ok ? (await chk.json().catch(() => ({}))).result : null;
    if (ex) return { statusCode: 200, body: JSON.stringify({ ok: true, existed: true }) };
    const set = await fetch(`${UPSTASH_URL}/set/${encodeURIComponent(key)}/${encodeURIComponent(ref)}`, { method: "POST", headers });
    if (!set.ok) return { statusCode: 500, body: JSON.stringify({ error: "kv set failed" }) };
    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  }
  return { statusCode: 405, body: "Method Not Allowed" };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
